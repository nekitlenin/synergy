a = float(input("Введите длину прямоугольника: "))
b = float(input("Введите ширину прямоугольника: "))

area = a * b
perimeter = 2 * (a + b)

print(f"Площадь прямоугольника: {area}")
print(f"Периметр прямоугольника: {perimeter}")